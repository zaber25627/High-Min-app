# TaskHive — Professional Advanced Token-Based Earning & Rewards Platform

TaskHive is an enterprise-grade token earning, micro-tasks, gaming, and rewards platform built for Telegram Mini Apps and web browsers.

## Project Structure
```
TaskHive-Advanced-Platform/
│
├── index.html           # Upgraded User Panel (5-button bottom nav, 4 games, token market, wallet)
├── admin.html           # Master Admin Panel (21 modules, responsive sidebar, user balance audit)
│
├── backend/
│   ├── functions/       # Server functions, notification proxy, price engine
│   ├── package.json
│   └── README.md
│
├── firebase/
│   ├── database.rules.json  # Production security rules
│   └── database.schema.md   # Schema documentation
│
├── config/
│   └── config.example.js    # Production configuration template
│
├── docs/
│   ├── INSTALLATION.md      # Deployment & setup guide
│   ├── ADMIN_GUIDE.md       # Admin panel guide
│   ├── DATABASE_GUIDE.md    # Database guide
│   ├── SECURITY_GUIDE.md    # Security & fraud prevention
│   └── FEATURE_GUIDE.md     # Feature reference
│
└── README.md
```

## Quick Start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Build & launch:
   ```bash
   npm run build
   npm start
   ```
3. Open in browser:
   - User Panel: `http://localhost:3000/` or `http://localhost:3000/index.html`
   - Admin Panel: `http://localhost:3000/admin.html`
   - Download ZIP Archive: `http://localhost:3000/api/download-zip`
