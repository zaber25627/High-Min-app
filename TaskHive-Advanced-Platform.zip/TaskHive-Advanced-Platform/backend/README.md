# TaskHive Backend Architecture & API Service

This backend service handles sensitive operations for the TaskHive Token-Based Platform:
1. **Telegram Notification Proxy**: Sends automated approvals, rejections, deposit receipts, and global broadcasts without exposing bot tokens to frontend clients.
2. **Automatic Token Price Engine**: Executes bounded periodic price movements according to configured minimum and maximum bounds.
3. **P2P Balance Transfers**: Executes atomic balance debits and credits with complete idempotency and negative balance protection.
4. **Leaderboard Freezing & Reward Distribution**: Server-side validation of scores and distribution of prize pools to Top 50 winners.

## Environment Variables
Create a `.env` file inside this directory:
```env
PORT=5000
TELEGRAM_BOT_TOKEN="YOUR_BOT_TOKEN_FROM_BOTFATHER"
FIREBASE_DATABASE_URL="https://taskhive-3db22.firebaseio.com"
```

## Running Backend
```bash
npm install
npm start
```
