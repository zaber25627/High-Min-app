# TaskHive Security & Fraud Prevention Guide

## 1. Telegram Bot Token Revocation Notice
> **CRITICAL SECURITY ALERT**:
> In earlier source code versions, a hardcoded Bot Token (`8642630962:...`) was exposed in client HTML.
> You must open [@BotFather](https://t.me/BotFather) in Telegram, send `/revoke`, select your bot, and generate a new token.
> Place the new token exclusively in server environment variables (`TELEGRAM_BOT_TOKEN`) or backend secrets managers. Never commit tokens to public repositories.

---

## 2. Server-Authoritative Balances
- User balances are stored in Firebase and protected by validation rules (`.validate: "newData.isNumber() && newData.val() >= 0"`).
- Direct client manipulation is prevented.
- Financial transactions (withdrawals, transfers, token trades) generate immutable ledger entries with timestamps and transaction IDs.

---

## 3. P2P Transfer Atomicity
- Transfer requests enforce receiver validation and self-transfer blocks.
- Sender deduction and receiver credit occur atomically with platform fee tracking.
- Idempotent transaction IDs (`TXF_timestamp`) prevent double-spend or duplicate transfers.

---

## 4. Multi-Account Device Fingerprinting
- Browser fingerprinting hashes screen metrics, language, and user agent to identify suspicious multi-accounting on the same physical device.
- Device limit flags accounts with more than 3 distinct user IDs on a single device.
