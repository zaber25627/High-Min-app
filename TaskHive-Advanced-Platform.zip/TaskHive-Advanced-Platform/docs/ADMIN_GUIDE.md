# TaskHive Admin Management Guide

This guide explains each of the 21 modules in the TaskHive Master Admin Console (`admin.html`).

---

## 1. Dashboard Overview
- Real-time statistics: Total users, 7-day active users, total deposits, total withdrawals, pending payouts, pending deposits, token price.
- Live stream of recent audit activities and transactions.

## 2. Withdrawal Management ($0 Fee Policy)
- View pending payout requests with user Telegram ID, payment gateway, and account number.
- Enforces strict **0% withdrawal fee** (no deduction).
- Clicking **Approve** marks request as approved and notifies user.
- Clicking **Reject** requests a mandatory reason and refunds the amount to the user's balance.

## 3. Manual Deposit Verification
- Filter by Pending, Approved, Rejected.
- View transaction reference (TxID) and screenshot proof.
- Approving deposits automatically credits the user's Task Balance for publishing community tasks.

## 4. Token & Price Engine Configuration
- Configure token name, symbol (HIVEX), logo URL.
- Set minimum and maximum price boundaries.
- Force immediate price ticks to simulate market momentum.

## 5. User Management & Audit Logs
- Search users by name or Telegram User ID.
- Inspect detailed balances (Main Cash, Task Creator Balance, Token Balance).
- **Balance Adjustments**: Adjustments require a **mandatory audit reason** which is stored in `/auditLogs` for compliance.
- Ban / Unban users to prevent fraudulent access.

## 6. Maintenance Mode
- Toggle Maintenance Mode ON or OFF.
- Customize maintenance announcement and estimated completion time.
- Standard users are blocked by a sleek overlay, while administrator bypass remains active.
