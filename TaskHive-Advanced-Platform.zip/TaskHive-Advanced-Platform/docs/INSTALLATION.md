# TaskHive Complete Installation & Setup Guide

This guide provides step-by-step instructions for deploying TaskHive across Firebase, Vercel/Cloud Run, and Telegram Mini Apps.

---

## 1. Prerequisites
- Node.js 18+ and npm
- A Firebase Project (with Realtime Database enabled)
- A Telegram Bot created via [@BotFather](https://t.me/BotFather)

---

## 2. Firebase Setup
1. Go to the [Firebase Console](https://console.firebase.google.com).
2. Create or select your project (`taskhive-3db22`).
3. Under **Build**, select **Realtime Database** and create a database in **Test mode** initially.
4. Go to **Rules** tab, paste the contents of `firebase/database.rules.json`, and click **Publish**.
5. Copy your Web App configuration and verify it in `index.html` and `admin.html`.

---

## 3. Server Installation
Run in the root directory:
```bash
npm install
npm run build
npm start
```
The server will start on port `3000` (or `PORT` specified in environment).
- User Panel: `http://localhost:3000/` or `http://localhost:3000/index.html`
- Admin Panel: `http://localhost:3000/admin.html`

---

## 4. Telegram Mini App Integration
1. Open Telegram and message [@BotFather](https://t.me/BotFather).
2. Send `/newapp` or `/myapps` and select your bot.
3. Set the Mini App title (e.g. `TaskHive VIP Earn`).
4. Set the Web App URL to your deployed domain (e.g. `https://your-domain.run.app`).
5. Choose a short name (e.g. `app`).
6. Your Mini App link is ready: `https://t.me/YourBotName/app`.
