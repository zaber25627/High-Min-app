# TaskHive Feature & Module Guide

## 1. User Panel Architecture
- **Five-Button Bottom Navigation**:
  1. `Home`: User avatar, balance hero with main cash and token summary, quick action cards, announcements ticker, live token banner, featured tasks preview, recent activities stream.
  2. `Tasks`: Daily tasks, social/Telegram tasks, community tasks created by users, create community task form.
  3. `Games`:
     - **Spin Wheel**: Canvas rendering, randomized segment pointer deceleration, sound/vibration feedback, daily spin limits.
     - **Lucky Box**: 6 interactive gift boxes with 3D shake and confetti unboxing.
     - **Scratch Card**: Interactive HTML5 canvas with metallic foil scratching, percentage scratched detection, instant claim.
     - **Number Guess**: Multiplier guessing between 1 and 10 with high/low hints.
     - **Daily Quiz**: Trivia questions with 15s timer.
  4. `Leaderboard`: Daily, Weekly, and Monthly Top 50 competitions, podiums, live countdown timers, reward pools.
  5. `Wallet`: Main cash, task balance, token assets, 0% fee withdrawal request, manual deposit submission, P2P balance transfer, full transaction ledger.

- **Explore & Sub-Pages**:
  - `Token Market`: Dedicated modal with live price, 24h change %, SVG chart, Buy & Sell order execution.
  - `Referral Center`: Link copying, Telegram sharing, milestone bonus tiers.
  - `Promo Codes`: Code redemption with instant balance crediting and duplicate prevention.
  - `Support Helpdesk`: Ticket creation and status resolution.
  - `Global Details Modal`: Every history item, transaction, task, game result, and notification is clickable to view complete verified details.
