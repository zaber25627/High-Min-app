/**
 * TaskHive Platform Configuration Example
 * Replace placeholder credentials with your production Firebase & Telegram keys.
 */

export const PlatformConfig = {
  // Firebase Web SDK Configuration
  firebase: {
    apiKey: "YOUR_FIREBASE_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
  },

  // Telegram Mini App Configuration
  telegram: {
    botUsername: "YourTaskHiveBot",
    supportChannelUrl: "https://t.me/your_support",
    officialUpdatesUrl: "https://t.me/your_channel"
  },

  // Token Parameters
  token: {
    name: "HiveToken",
    symbol: "HIVEX",
    initialPrice: 1.25,
    minPrice: 0.80,
    maxPrice: 2.50,
    updateIntervalMinutes: 5
  },

  // Financial Rules
  financial: {
    withdrawalFeePercent: 0, // Mandatory $0 fee
    transferFeePercent: 2,
    minimumWithdrawal: 10,
    dailyBonusAmount: 20,
    referralBonusAmount: 5
  }
};
