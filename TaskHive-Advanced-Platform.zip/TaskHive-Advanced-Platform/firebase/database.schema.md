# TaskHive Database Schema Specification

This document details the complete production database schema implemented for Firebase Realtime Database with full backward compatibility for all existing records and new enterprise modules.

---

## 1. Schema Hierarchy & Paths

```
/
├── config/
│   ├── botUsername: string
│   ├── currencySymbol: string
│   ├── dailyBonusAmount: number
│   ├── refBonus: number
│   ├── withdrawRefRequired: number
│   ├── withdrawEnabled: boolean
│   ├── withdrawNotice: string
│   ├── paymentMethods: array[string]
│   ├── taskBalanceSettings: object
│   ├── webTasks: { [taskId]: { name, reward, url, icon } }
│   ├── refTasks: { [taskId]: { title, requiredRefs, reward } }
│   └── maintenance: { enabled: boolean, message: string, timestamp: number }
│
├── depositMethods/
│   └── [methodId]: { name, address, qrCode, icon, enabled }
│
├── promoCodes/
│   └── [code]: { reward: number, limit: number, used: number, enabled: boolean, createdAt: number }
│
├── users/
│   └── [userId]:
│       ├── id: string (Telegram User ID)
│       ├── name: string
│       ├── username: string
│       ├── avatar: string (URL)
│       ├── balance: number (Main cash balance)
│       ├── taskBalance: number (Balance reserved for publishing community tasks)
│       ├── tokenBalance: number (HIVEX token balance)
│       ├── totalEarned: number
│       ├── totalWithdrawn: number
│       ├── referrals: number
│       ├── isBanned: boolean
│       ├── banReason: string
│       ├── dailyBonusDate: string (YYYY-MM-DD)
│       ├── taskHistory: { [taskId]: timestamp }
│       ├── usedPromos: { [code]: timestamp }
│       ├── withdrawHistory: { [wdId]: WithdrawalRecord }
│       ├── depositHistory: { [depId]: DepositRecord }
│       └── activityLogs: { [actId]: ActivityRecord }
│
├── withdrawals/
│   └── [wdId]:
│       ├── wdId: string
│       ├── userId: string
│       ├── userName: string
│       ├── method: string (Bkash, Nagad, Binance, etc.)
│       ├── account: string
│       ├── amount: number
│       ├── chargePct: 0 (Strictly 0% fee mandate)
│       ├── chargeAmount: 0
│       ├── finalAmount: number (equals amount)
│       ├── status: "pending" | "approved" | "rejected"
│       ├── rejectReason?: string
│       └── timestamp: number
│
├── deposits/ & depositRequests/
│   └── [depId]:
│       ├── depId: string
│       ├── userId: string
│       ├── userName: string
│       ├── method: string
│       ├── amount: number
│       ├── txId: string
│       ├── transactionId: string
│       ├── screenshot?: string (Base64 or image URL)
│       ├── status: "pending" | "approved" | "rejected"
│       ├── adminNote?: string
│       └── timestamp: number
│
├── activeTasks/ & userTasks/
│   └── [taskId]:
│       ├── taskId: string
│       ├── creatorId: string
│       ├── creatorName: string
│       ├── title: string
│       ├── link: string
│       ├── type: string
│       ├── reward: number
│       ├── participantLimit: number
│       ├── participantsCompleted: number
│       ├── status: "active" | "completed" | "paused" | "rejected"
│       └── timestamp: number
│
├── transfers/
│   └── [transferId]:
│       ├── transferId: string
│       ├── senderId: string
│       ├── senderName: string
│       ├── receiverId: string
│       ├── amount: number
│       ├── fee: number
│       ├── receivedAmount: number
│       ├── status: "completed"
│       └── timestamp: number
│
├── tokenTransactions/
│   └── [txId]:
│       ├── txId: string
│       ├── userId: string
│       ├── userName: string
│       ├── mode: "buy" | "sell"
│       ├── quantity: number
│       ├── pricePerToken: number
│       ├── totalAmount: number
│       └── timestamp: number
│
├── auditLogs/
│   └── [logId]:
│       ├── logId: string
│       ├── action: "BALANCE_CREDIT" | "BALANCE_DEBIT"
│       ├── targetUserId: string
│       ├── targetUserName: string
│       ├── amount: number
│       ├── previousBalance: number
│       ├── newBalance: number
│       ├── reason: string (MANDATORY)
│       ├── adminSignature: string
│       └── timestamp: number
│
├── supportTickets/
│   └── [ticketId]:
│       ├── ticketId: string
│       ├── userId: string
│       ├── userName: string
│       ├── subject: string
│       ├── message: string
│       ├── status: "open" | "resolved"
│       └── timestamp: number
│
└── activityLogs/
    └── [actId]:
        ├── id: string
        ├── userId: string
        ├── userName: string
        ├── type: string
        ├── title: string
        ├── amount: number
        ├── status: string
        └── timestamp: number
```
